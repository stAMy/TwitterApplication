package com.example.bojar.twitterapplication;

import android.content.Intent;
import android.service.media.MediaBrowserService;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Toolbar;
import com.twitter.sdk.android.Twitter;
import com.twitter.sdk.android.core.TwitterAuthConfig;
import com.twitter.sdk.android.core.TwitterException;
import com.twitter.sdk.android.core.TwitterSession;
import com.twitter.sdk.android.core.identity.TwitterLoginButton;
import com.twitter.sdk.android.core.Callback;
import io.fabric.sdk.android.Fabric;
import com.twitter.sdk.android.core.Result;
import com.twitter.sdk.android.core.models.Tweet;
import com.twitter.sdk.android.tweetui.TweetUtils;
import com.twitter.sdk.android.tweetui.TweetView;


public class MainActivity extends AppCompatActivity {


    private static final String TWITTER_KEY = "SZlFqJjYvfY1PME90T8XzDRmV";
    private static final String TWITTER_SECRET = "YzMuc8TWY0xcjNXjs9LzoMxQqMqlAWWrXW1XjmoNwslcxyTGtP";

    private TwitterLoginButton loginButton;
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TwitterAuthConfig authConfig = new TwitterAuthConfig(TWITTER_KEY, TWITTER_SECRET);
        Fabric.with(this, new Twitter(authConfig));
        setContentView(R.layout.activity_main);




        loginButton = (TwitterLoginButton) findViewById(R.id.twitter_login_button);
        status = (TextView) findViewById(R.id.status);
        status.setText("Status: Ready");

        loginButton.setCallback(new Callback<TwitterSession>()

                                {
                                    @Override
                                    public void success(Result<TwitterSession> result) {
                                        String UserName = result.data.getUserName();
                                        Toast.makeText(MainActivity.this, UserName, Toast.LENGTH_LONG).show();

                                        String output = "Status: " + result.data.getUserName() + "\nAuth Token Received " + result.data.getAuthToken().token;

                                        //status.setText(output);

                                        Intent intent = new Intent(MainActivity.this, FrontPageAfterLogin.class);
                                        startActivity(intent);
                                    }

                                    @Override
                                    public void failure(TwitterException exception) {
                                        status.setText("Status: login Failed");
                                    }
                                }

        );
/*

        // TODO: Use a more specific parent
        final ViewGroup parentView = (ViewGroup) getWindow().getDecorView().getRootView();
        // TODO: Base this Tweet ID on some data from elsewhere in your app
        long tweetId = 700311394328010753L;

        TweetUtils.loadTweet(tweetId, new Callback<Tweet>() {
            @Override
            public void success(Result<Tweet> result) {
                TweetView tweetView = new TweetView(MainActivity.this, result.data);
                parentView.addView(tweetView);
            }

            @Override
            public void failure(TwitterException exception) {
                Log.d("TwitterKit", "Load Tweet failure", exception);
            }
        });
*/

    }

    //Gir

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        // Make sure that the loginButton hears the result from any
        // Activity that it triggered.
        loginButton.onActivityResult(requestCode, resultCode, data);
    }


}
